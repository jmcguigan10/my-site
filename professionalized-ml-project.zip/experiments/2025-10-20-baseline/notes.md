> Navigation: [Home](../../docs/index.md) · [Site Map](../../docs/site-map.md) · [Code Browser](../../docs/code-browser.md)

# Baseline notes (2025-10-20)

- Purpose: sanity check the pipeline with default YAML.
- Outcome: fill this in after running.