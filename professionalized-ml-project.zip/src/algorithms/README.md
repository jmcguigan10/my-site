> Navigation: [Home](../../docs/index.md) · [Site Map](../../docs/site-map.md) · [Code Browser](../../docs/code-browser.md)

# algorithms

Optimizers live here. Each implements a `step(params, grads)` method and carries any internal state.